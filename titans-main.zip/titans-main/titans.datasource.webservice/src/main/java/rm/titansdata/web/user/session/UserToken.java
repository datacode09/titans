
package rm.titansdata.web.user.session;

/**
 *
 * @author Ricardo Marquez
 */
public class UserToken {
  
}
