package rm.titansdata.web.user.login;

/**
 *
 * @author Ricardo Marquez
 */
public class InvalidUserException extends Exception {
  
}
