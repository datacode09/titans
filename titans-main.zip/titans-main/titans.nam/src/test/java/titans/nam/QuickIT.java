package titans.nam;

import org.junit.Test;

/**
 *
 * @author Ricardo Marquez
 */
public class QuickIT {
  
  @Test
  public void test() {
    System.out.println(String.format("%03d", 3));    
    
  }
}
