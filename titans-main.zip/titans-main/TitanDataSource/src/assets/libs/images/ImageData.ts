
export class ImageData {
  
  constructor(private data:number[]){
  }
  
  public toimage():void {
    
  }
}
