import {OnInit, Component} from '@angular/core';

@Component({
  selector : "footer-root"
  , templateUrl : "./footer.component.html"
  , styleUrls : ["../app.component.css", 'footer.component.css']
})
export class FooterComponent implements OnInit{
  /**
   * 
   */
  public ngOnInit(): void {
    
  }
  
}


