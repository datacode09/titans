import {Component, OnInit} from '@angular/core';


@Component({
  selector : "projects-root"
  , templateUrl : "./projects.component.html"
  , styleUrls : ["./../../app/app.component.css", "projects.component.css"]
})
export class ProjectsComponent implements OnInit{
  
  /**
   * 
   */
  public constructor() {    
  }
  /**
   * 
   */
  public ngOnInit(): void {  
  }
}