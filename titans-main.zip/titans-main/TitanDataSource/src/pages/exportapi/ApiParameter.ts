/**
 * 
 */
export class ApiParameter {
  public argname:string;
  public argtype:string; 
  
  /**
   * 
   */
  public constructor(argname:string, argtype:string) {
    this.argname = argname;
    this.argtype = argtype;
  }
  
  
}