
/**
 * 
 */
export interface DetailsView {

  /**
   * 
   */
  getTitle(): string;

  /**
   * 
   */
  getElement(): any;

}
