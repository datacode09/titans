
/**
 * 
 */
export class SeriesProperties {
  public color: string;

  /**
   * 
   */
  public constructor(arg: {color: string}) {
    this.color = arg.color;
  }


}