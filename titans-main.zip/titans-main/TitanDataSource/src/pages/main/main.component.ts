import {Component, OnInit} from '@angular/core';


@Component({
  selector: 'main-root',
  templateUrl: './main.component.html',
//  styleUrls: ['../../app/app.component.css']
})
export class MainComponent implements OnInit {
  /**  
   * 
   */
  public ngOnInit(): void {
  }

}

