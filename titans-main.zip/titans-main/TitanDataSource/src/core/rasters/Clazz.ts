
/**
 * 
 */
export class Clazz {
  public key:string;
  public obj:any;
  
  /**
   * 
   */
  public constructor(key:string, obj:any) {
    this.key = key;
    this.obj = obj;
  }
}
