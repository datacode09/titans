
/**
 * 
 */
export class RasterEntity {
  public rasterId: number;
  
  /**
   * 
   */
  public constructor(rasterId: number) {
    this.rasterId = rasterId;
  }
}
