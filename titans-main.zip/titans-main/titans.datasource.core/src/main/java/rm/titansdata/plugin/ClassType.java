package rm.titansdata.plugin;

/**
 *
 * @author Ricardo Marquez
 */
public interface ClassType {
  
  /**
   * 
   * @return 
   */
  public String name();
}
