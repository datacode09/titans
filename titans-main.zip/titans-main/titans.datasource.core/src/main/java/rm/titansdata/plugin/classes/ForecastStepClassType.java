package rm.titansdata.plugin.classes;

/**
 *
 * @author Ricardo Marquez
 */
public class ForecastStepClassType extends BaseClassType{

  
    
  /**
   * 
   */
  public ForecastStepClassType() {
    super("FORECAST_STEP");
  }
  

}
