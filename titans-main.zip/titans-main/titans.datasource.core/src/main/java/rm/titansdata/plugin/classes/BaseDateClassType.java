package rm.titansdata.plugin.classes;

/**
 *
 * @author Ricardo Marquez
 */
public class BaseDateClassType extends BaseClassType {

  
  public BaseDateClassType() {
    super("BASE_DATE");
  }
     
}
