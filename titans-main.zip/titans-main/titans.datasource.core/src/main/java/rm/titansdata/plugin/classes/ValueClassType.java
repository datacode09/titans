package rm.titansdata.plugin.classes;

/**
 *
 * @author Ricardo Marquez
 */
public class ValueClassType extends BaseClassType{
  
  public ValueClassType(String name) {
    super(name);
  }
  
}
