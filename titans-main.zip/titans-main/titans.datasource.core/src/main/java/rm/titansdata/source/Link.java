package rm.titansdata.source;

/**
 *
 * @author Ricardo Marquez
 */
public class Link {
  
}
