package rm.titansdata.plugin;

/**
 *
 * @author Ricardo Marquez
 */
public interface Clazz {
  
  /**
   * 
   * @return 
   */
  public String getKey();
  
  
  /**
   * 
   */
  public String toJson();
}
